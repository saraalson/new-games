// NOTE object below must be a valid JSON
window.game46 = $.extend(true, window.game46, {
  "config": {
    "layoutSet": "navbar",
    "navigation": []
  }
});