// NOTE object below must be a valid JSON
window.game39 = $.extend(true, window.game39, {
  "config": {
    "layoutSet": "navbar",
    "navigation": []
  }
});