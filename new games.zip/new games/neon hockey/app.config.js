// NOTE object below must be a valid JSON
window.game44 = $.extend(true, window.game44, {
  "config": {
    "layoutSet": "navbar",
    "navigation": []
  }
});