// NOTE object below must be a valid JSON
window.game23 = $.extend(true, window.game23, {
  "config": {
    "layoutSet": "navbar",
    "navigation": []
  }
});